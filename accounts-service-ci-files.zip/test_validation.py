"""Tests for service configuration."""
import unittest
from app import app


class ValidationTests(unittest.TestCase):
    def test_flask_application(self):
        self.assertEqual(app.name, "app")
