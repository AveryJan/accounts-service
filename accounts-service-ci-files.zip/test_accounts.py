"""Tests for the service API."""
import unittest
from app import app


class AccountsTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_root(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["message"], "SERVICERUNNING")

    def test_health(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], "ok")
